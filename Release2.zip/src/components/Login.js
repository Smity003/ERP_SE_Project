import React from "react";
import { Link } from "react-router-dom";

export default function Login({ usertype, goto }) {
  const myStyle = {
    backgroundImage: `url("/images/img1.jpg")`,
    height: "100vh",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };
  return (
    <div style={myStyle} className="shadow-lg p-3 bg-body text-center rounded">
      <br />
      <br />
      <br />
      <br />
      <div className="container p-3 bg-light w-25 mt-0">
        <img src="images/img2.jpg" alt="" style={{ width: "40%" }} />
        <div>Indian Institute of Technology Tirupati</div>
        <div className="text-danger">Welcome to {usertype} Login</div>
        <br />
        <form className="text-start">
          <div className="mb-1">
            <label for="exampleInputEmail1" className="form-label mb-0">
              Email address
            </label>
            <input
              type="text"
              className="form-control mt-0"
              id="InputUsername"
              input="Username"
            />
          </div>
          <div className="mb-3">
            <label for="InputPassword" className="form-label mb-0">
              Password
            </label>
            <input
              type="password"
              className="form-control mt-0"
              id="InputPassword1"
              placeholder="Password"
            />
          </div>
          <Link to={goto}>
            <button type="submit" className="btn btn-sm btn-primary w-100">
              Submit
            </button>
          </Link>
        </form>
      </div>
    </div>
  );
}
