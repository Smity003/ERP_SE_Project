import React from "react";

export default function Homepage({ name, doj, deg, mob, depart, rn }) {
  return (
    <>
      <div>
        <div
          className="card container"
          style={{ width: "28rem", height: "80vh" }}
        >
          <div className="fs-4">
            Hello <b>{name}</b>{" "}
          </div>
          <img
            src="/images/WebMonsterlogo.png"
            className="card-img-top rounded-circle py-2 px-5 w-75 m-auto"
            alt="..."
          />
          <div className="card-body d-flex flex-column fs-6">
            <div className="d-flex mb-1">
              <div
                className="d-flex justify-content-end"
                style={{ width: "30%" }}
              >
                Roll Number :{" "}
              </div>
              <div> &nbsp; {rn}</div>
            </div>
            <div className="d-flex mb-1">
              <div
                className="d-flex justify-content-end"
                style={{ width: "31%" }}
              >
                Date of Joining :{" "}
              </div>
              <div> &nbsp; {doj}</div>
            </div>
            <div className="d-flex mb-1">
              <div
                className="d-flex justify-content-end"
                style={{ width: "30%" }}
              >
                Department :{" "}
              </div>
              <div> &nbsp; {depart}</div>
            </div>
            <div className="d-flex mb-1">
              <div
                className="d-flex justify-content-end"
                style={{ width: "30%" }}
              >
                Designation :{" "}
              </div>
              <div> &nbsp; {deg}</div>
            </div>
            <div className="d-flex mb-1">
              <div
                className="d-flex justify-content-end"
                style={{ width: "30%" }}
              >
                Mobile No :{" "}
              </div>
              <div> &nbsp; {mob}</div>
            </div>
            <div className="d-flex mb-1">
              <div
                className="d-flex justify-content-end"
                style={{ width: "30%" }}
              >
                Email :{" "}
              </div>
              <div> &nbsp; {rn}@iittp.ac.in</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
