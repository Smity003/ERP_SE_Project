import React, { useState } from "react";

export default function AGrievane() {
  const [griev, setGriev] = useState([{ griev: "" }]);

  const handleGrievChange = (e, index) => {
    const { name, value } = e.target;
    const list = [...griev];
    list[index][name] = value;
    setGriev(list);
  };

  const handleGrievRemove = (index) => {
    const list = [...griev];
    list.splice(index, 1);
    setGriev(list);
  };

  const handleGrievAdd = () => {
    setGriev([...griev, { griev: "" }]);
  };
  const myInput = {
    height: "35px",
    width: "40vw",
    padding: "7px",
    outline: "none",
    borderRadius: "5px",
    border: "1px solid rgb(220, 220, 220)",
    margin: "6px 0",
  };
  return (
    <form className="App" autoComplete="off">
      <div className="form-field">
        <h2>Grievances</h2>
        {griev.map((singleGriev, index) => (
          <div key={index} className="d-flex justify-content-center">
            <div className="first-division">
              <input
                style={myInput}
                name="griev"
                type="text"
                id="griev"
                value={singleGriev.Griev}
                onChange={(e) => handleGrievChange(e, index)}
                required
              />
              {griev.length - 1 === index && griev.length < 25 && (
                <button
                  type="button"
                  onClick={handleGrievAdd}
                  className="btn btn-sm btn-success d-flex align-self-start align-items-center mt-2"
                >
                  <span>Add a Griev</span>
                </button>
              )}
            </div>
            <div className="second-division">
              {griev.length !== 1 && (
                <button
                  type="button"
                  onClick={() => handleGrievRemove(index)}
                  className="btn btn-info btn-sm mt-2 mb-2"
                >
                  <span>Remove</span>
                </button>
              )}
            </div>
            <br />
          </div>
        ))}
      </div>
    </form>
  );
}
