import React from "react";
import { Link } from "react-router-dom";

export default function Mainage() {
  const myStyle = {
    backgroundImage: `url("/images/img1.jpg")`,
    height: "100vh",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
  };
  return (
    <div style={myStyle} className="shadow-lg p-3 text-center bg-body rounded">
      <br />
      <br />
      <br />
      <br />
      <div className="container p-3 bg-light w-25 mt-0">
        <img src="images/img2.jpg" alt="" style={{ width: "40%" }} />
        <hr className="mt-0 mb-0" />
        <div>Welcome to IIT Tirupati E-Governance</div>
        <hr className="mt-0 mb-0" />
        <Link to="/student">
          <div className="container w-75 shadow border border-secondary p-2 mb-2 mt-3 text-primary rounded">
            Student Login
          </div>
        </Link>
        <Link to="/faculty">
          <div className="container w-75 shadow border border-secondary p-2 mb-2 mt-3 text-primary rounded">
            Faculty/Staff Login
          </div>
        </Link>
        <Link to="/admin">
          <div className="container w-75 shadow border border-secondary p-2 mb-2 mt-3 text-primary rounded">
            Admin Login
          </div>
        </Link>
      </div>
    </div>
  );
}
