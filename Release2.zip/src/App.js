import "./App.css";
import Login from "./components/Login";
import Mainpage from "./components/Mainpage";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import SLayout from "./components/SLayout";
import FLayout from "./components/FLayout";
import ALayout from "./components/ALayout";

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Mainpage />} />
        <Route
          exact
          path="/faculty"
          element={
            <Login usertype="Faculty/Staff" goto="/faculty/faculty_page" />
          }
        />
        <Route
          exact
          path="/student"
          element={<Login usertype="Student" goto="/student/student_page" />}
        />
        <Route
          exact
          path="/admin"
          element={<Login usertype="Admin" goto="/admin/admin_page" />}
        />
        <Route exact path="/student/student_page/*" element={<SLayout />} />
        <Route exact path="/faculty/faculty_page/*" element={<FLayout />} />
        <Route exact path="/admin/admin_page/*" element={<ALayout />} />
      </Routes>
    </Router>
  );
}

export default App;
